﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;
using SendGrid;
using SendGrid.Helpers.Mail;
using System.Threading;
using System.Configuration;
using System.IO;
using CreditReversalService;
using System.Data.SqlClient;
using System.Security.Cryptography;
using System.Xml;
using System.Timers;
using Timer = System.Timers.Timer;

namespace CreditReversalService
{
    [RunInstaller(true)]
    public partial class Service1 : ServiceBase
    {
        Timer _timer1 = new Timer();
        public Service1()
        {
            InitializeComponent();
        }
        protected override void OnStart(string[] args)
        {   //Reminder Mails for 14 and 7 days before billing
            SetMessage("Start: " + DateTime.Now);
            _timer1.Elapsed += new ElapsedEventHandler(RemindersPayments);
            _timer1.Interval = (1000 * 60 * 1);
            _timer1.Enabled = true;

        }
        protected void RemindersPayments(object sender, ElapsedEventArgs args)
        {
            try
            {
                _timer1.Enabled = false;
                _timer1.Stop();

                try { SendMails(); }
                catch (Exception ex) { SetMessage(ex.Message); }
                //Authorize.net credit card payments
                try { AgentPayments(); }
                catch (Exception ex) { SetMessage(ex.Message); }
                //2nd attempt payments
                try { AgentPaymentsNextAttempt(); }
                catch (Exception ex) { SetMessage(ex.Message); }

                _timer1.Enabled = true;
                _timer1.Start();
            }
            catch (Exception ex)
            {
                SetMessage("RemindersPayments: " + ex.ToString());
            }
        }
        public int sendmail(string Email, string Subject, string Name, string body, string MailType)
        {
            int mailsent = 0;
            XmlDataDocument xmldoc = new XmlDataDocument();
            XmlNodeList xmlnode;
            FileStream fs = new FileStream(AppDomain.CurrentDomain.BaseDirectory + "\\CreditReversal.xml", FileMode.Open, FileAccess.Read);
            xmldoc.Load(fs);
            string fromemail = xmldoc.GetElementsByTagName("fromemail")[0].ChildNodes.Item(0).InnerText.Trim();
            try
            {

                int i = 0;
                string str = null;

                string apiKey = xmldoc.GetElementsByTagName("SendGridAPIKey")[0].ChildNodes.Item(0).InnerText.Trim();

                //string apiKey = "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";
                //string fromemail = "testm3consulting@gmail.com";

                // string apiKey = ConfigurationManager.AppSettings["sendgridapikey"];
                // string fromemail = ConfigurationManager.AppSettings["fromemail"];
                dynamic client = new SendGridClient(apiKey);
                var client1 = new SendGridClient(apiKey);
                var from = new EmailAddress(fromemail, "Support-CreditReversalGuru");
                var subject = Subject;
                var to = new EmailAddress(Email, Name);
                var plainTextContent = "and easy to do anywhere, even with C# even with C#";
                var htmlContent = "<strong>Thanks , <br> </strong>";
                var msg = MailHelper.CreateSingleEmail(from, to, subject, plainTextContent, body);
                var response = client.SendEmailAsync(msg);
                if (response.Result.StatusCode == System.Net.HttpStatusCode.Unauthorized)
                {
                    mailsent = 0;
                    InsertAgentMail(Email, Subject, Name, body, fromemail, MailType, "0", "Unauthorized");
                }
                else if (response.Result.StatusCode == System.Net.HttpStatusCode.Accepted)
                {
                    mailsent = 1;
                    InsertAgentMail(Email, Subject, Name, body, fromemail, MailType, "1", "");
                }
                else
                {
                    mailsent = 0;
                    InsertAgentMail(Email, Subject, Name, body, fromemail, MailType, "1", response.Result.StatusCode);
                }
            }
            catch (Exception ex)
            {
                SetMessage("sendmail: " + ex.Message);
                InsertAgentMail(Email, Subject, Name, body, fromemail, MailType, "0", ex.Message);
            }
            return mailsent;
        }
        public void InsertAgentMail(string Email, string Subject, string Name, string body, string FromEmail, string MailType, string MailStatus, string ErrorMsg)
        {
            try
            {
                string sql = "  INSERT  INTO AgentMails(Agent,Subject,Body,FromEmail,ToEmail,MailType,MailStatus,ErrorMsg "
                    + "  ) VALUES('" + Name + "','" + Subject + "','" + body + "','" + FromEmail + "',  '" + Email
                    + "', '" + MailType + "', '" + MailStatus + "', '" + ErrorMsg + "')";
                DBUtilities utilities = new DBUtilities();
                utilities.ExecuteString(sql, true);
            }
            catch (Exception ex)
            { SetMessage("InsertAgentMail" + ex.Message); }
        }
        public void SendMails()
        {

            int res = 0;
            try
            {
                string sql = " SELECT a.PaymentStatus,c.FirstName+' '+c.LastName agentname,c.BillingEmail, a.AgentId, "
                  + " CONVERT(VARCHAR(10),  max(a.PaymentDate), 101) as paydate,b.BillingType, "
                  + " isnull([14days],0) twoweeks, isnull([7days],0) oneweek,isnull(isNextAttempt,0) nextattempt, "
                  + " isnull(isNextAttemptMail,0) nextattemptmail FROM Billing a, AgentBilling b,Agent c"
                  + " where a.PaymentMethodId = b.AgentBillingId and c.AgentId = b.AgentId and c.Status=1 " // and a.PaymentStatus='SUCCESS'"
                  + " group by a.PaymentStatus,c.BillingEmail, a.AgentId,b.BillingType,FirstName,LastName,[14days],[7days], "
                  + " isNextAttempt,isNextAttemptMail";
                DBUtilities utilities = new DBUtilities();
                DataTable dt = utilities.GetDataTable(sql);
                StringBuilder sb14 = new StringBuilder();
                StringBuilder sb7 = new StringBuilder();
                StringBuilder nxtAttempt = new StringBuilder();
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    DateTime currentdate = DateTime.Now.Date;
                    //String date = currentdate.ToShortDateString();
                    DateTime nextdue = DateTime.Now.Date;
                    DateTime paydate = dt.Rows[i]["paydate"].ToString().stringToCultureInfoDateTime();

                    string BillingType = dt.Rows[i]["BillingType"].ToString();
                    string PaymentStatus = dt.Rows[i]["PaymentStatus"].ToString();

                    if (PaymentStatus.ToUpper() == "SUCCESS")
                    {
                        if (BillingType.ToUpper() == "MONTHLY")
                        {
                            nextdue = paydate.AddMonths(1);
                            // string kol = ko.ToString("dd/MM/yyyy");

                        }
                        else if (BillingType.ToUpper() == "Quarterly")
                        {
                            nextdue = paydate.AddMonths(4);
                        }
                        else if (BillingType.ToUpper() == "Half-Yearly")
                        {
                            nextdue = paydate.AddMonths(6);
                        }
                        else if (BillingType.ToUpper() == "Annually")
                        {
                            nextdue = paydate.AddMonths(12);
                        }
                        bool twoweeks = false, oneweek = false;
                        if (dt.Rows[i]["twoweeks"] != null)
                        {
                            twoweeks = Convert.ToBoolean(dt.Rows[i]["twoweeks"]);
                        }
                        if (dt.Rows[i]["oneweek"] != null)
                        {
                            oneweek = Convert.ToBoolean(dt.Rows[i]["oneweek"]);
                        }
                        if (!twoweeks)
                        {
                            DateTime k = nextdue.AddDays(-14);
                            if (nextdue.AddDays(-14) == currentdate)
                            {
                                sb14.Append(dt.Rows[i]["agentname"].ToString() + "~" + dt.Rows[i]["BillingEmail"].ToString()
                                    + "~" + nextdue.DateTimeToMMDDYYYYString() + "~" + dt.Rows[i]["paydate"].ToString()
                                    + "~" + dt.Rows[i]["AgentId"].ToString() + "~14^");
                            }
                        }
                        if (!oneweek)
                        {
                            if (nextdue.AddDays(-7) == currentdate)
                            {
                                sb7.Append(dt.Rows[i]["agentname"].ToString() + "~" + dt.Rows[i]["BillingEmail"].ToString()
                                    + "~" + nextdue.DateTimeToMMDDYYYYString() + "~" + dt.Rows[i]["paydate"].ToString()
                                    + "~" + dt.Rows[i]["AgentId"].ToString() + "~7^");
                            }
                        }
                    }
                    else
                    {
                        bool nextattempt = Convert.ToBoolean(dt.Rows[i]["nextattempt"]);
                        bool nextattemptMail = Convert.ToBoolean(dt.Rows[i]["nextattemptmail"]);
                        if (nextattempt && !nextattemptMail)
                        {
                            nextdue = paydate.AddDays(6);
                            if (nextdue == currentdate)
                            {
                                nxtAttempt.Append(dt.Rows[i]["agentname"].ToString() + "~" + dt.Rows[i]["BillingEmail"].ToString()
                                  + "~" + nextdue.AddDays(1).DateTimeToMMDDYYYYString() + "~" + dt.Rows[i]["paydate"].ToString()
                                  + "~" + dt.Rows[i]["AgentId"].ToString() + "~nxtAttempt^");
                            }
                        }
                    }
                }

                string[] strNxtAtC = nxtAttempt.ToString().Split('^');

                if (strNxtAtC.Length > 1)
                {
                    for (int i = 0; i < strNxtAtC.Length - 1; i++)
                    {
                        string[] strNxtAtT = strNxtAtC[i].Split('~');
                        string agent = strNxtAtT[0], email = string.Empty, mode = string.Empty,
                            nextduedate = string.Empty, paydate = string.Empty, agentid = string.Empty;
                        if (agent != "")
                        {
                            email = strNxtAtT[1];
                            mode = strNxtAtT[5];
                            nextduedate = strNxtAtT[2];
                            paydate = strNxtAtT[3];
                            agentid = strNxtAtT[4];
                        }
                        string Subject = "Payment Reminder.";
                        if (email != "")
                        {
                            int result = sendmail(email, Subject, agent, mailtemplate(mode, agent, nextduedate), "Payment Next Attempt Reminder");
                            if (result > 0)
                            {
                                sql = "UPDATE BILLING set isNextAttemptMail=1 where CONVERT(VARCHAR(10),  PaymentDate, 101)='" + paydate + "' and agentid=" + agentid;
                                utilities.ExecuteString(sql, true);
                            }
                        }
                    }
                }

                string[] str14C = sb14.ToString().Split('^');
                if (str14C.Length > 1)
                {
                    for (int i = 0; i < str14C.Length - 1; i++)
                    {
                        string[] str14T = str14C[i].Split('~');
                        string agent = str14T[0], email = string.Empty, mode = string.Empty,
                            nextduedate = string.Empty, paydate = string.Empty, agentid = string.Empty;
                        if (agent != "")
                        {
                            email = str14T[1];
                            mode = str14T[5];
                            nextduedate = str14T[2];
                            paydate = str14T[3];
                            agentid = str14T[4];
                        }
                        string Subject = "Payment Reminder.";
                        if (email != "")
                        {
                            int result = sendmail(email, Subject, agent, mailtemplate(mode, agent, nextduedate), "14 days before reminder");
                            if (result > 0)
                            {
                                sql = "UPDATE BILLING set [14days]=1 where CONVERT(VARCHAR(10),  PaymentDate, 101)='" + paydate + "' and agentid=" + agentid;
                                utilities.ExecuteString(sql, true);
                            }
                        }
                    }
                }


                string[] str7C = sb7.ToString().Split('^');
                if (str7C.Length > 1)
                {
                    for (int i = 0; i < str7C.Length - 1; i++)
                    {
                        string[] str7T = str7C[i].Split('~');
                        string agent = str7T[0], email = string.Empty, mode = string.Empty, nextduedate = string.Empty, paydate = string.Empty, agentid = string.Empty;
                        if (agent != "")
                        {
                            email = str7T[1];
                            mode = str7T[5];
                            nextduedate = str7T[2];
                            paydate = str7T[3];
                            agentid = str7T[4];
                        }
                        string Subject = "Payment Reminder.";
                        if (email != "")
                        {
                            int result = sendmail(email, Subject, agent, mailtemplate(mode, agent, nextduedate), "7 days before reminder");
                            if (result > 0)
                            {
                                sql = "UPDATE BILLING set [7days]=1 where CONVERT(VARCHAR(10),  PaymentDate, 101)='" + paydate + "' and agentid=" + agentid;
                                utilities.ExecuteString(sql, true);
                            }
                        }
                    }
                }

            }
            catch (Exception ex)
            { SetMessage("SendMails" + ex.Message); }
        }
        public int AgentPayments()
        {
            int res = 0;
            try
            {
                string sql = " SELECT  a.PaymentStatus,a.PaymentMethodId,c.BillingPhone, c.BusinessName, c.BillingZip, c.BillingState, c.BillingCity, "
                    + " c.BillingAdd1,c.BillingAdd2, p.SetupFee,b.CardNumber,b.CardType,b.CVV,b.ExpiryDate , "
                  + " c.FirstName+' '+c.LastName agentname,c.BillingEmail, a.AgentId, "
                  + "  CONVERT(VARCHAR(10),  max(a.PaymentDate), 101)  paydate,b.BillingType FROM Billing a, AgentBilling b,Agent c , Pricing p "
                  + " where a.PaymentMethodId = b.AgentBillingId and c.AgentId = b.AgentId and p.PricingId=c.PricingPlan and "
                  + " isnull(isNextAttempt,0)=0 and isnull(isNextAttemptMail,0)=0 and c.Status=1 "
                  + "  and PaymentDate in (select max(PaymentDate) from Billing where AgentId=a.AgentId) "
                  + " group by   a.PaymentStatus,a.PaymentMethodId,c.BillingEmail, a.AgentId,b.BillingType,FirstName,LastName, "
                  + " b.CardNumber,b.CardType,b.CVV,b.ExpiryDate , p.SetupFee,c.BillingZip, c.BillingState, c.BillingCity, c.BillingAdd1,"
                  + " c.BillingAdd2,c.BillingPhone, c.BusinessName ";
                DBUtilities utilities = new DBUtilities();
                DataTable dt = utilities.GetDataTable(sql);
                StringBuilder sb = new StringBuilder();
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    string paymentstatus = dt.Rows[i]["PaymentStatus"].ToString();
                    if (paymentstatus.ToUpper() == "SUCCESS")
                    {
                        DateTime currentdate = DateTime.Now.Date;
                        DateTime nextdue = DateTime.Now.Date;
                        DateTime paydate = dt.Rows[i]["paydate"].ToString().stringToCultureInfoDateTime();
                        string BillingType = dt.Rows[i]["BillingType"].ToString();
                        if (BillingType.ToUpper() == "MONTHLY")
                        {
                            nextdue = paydate.AddMonths(1);
                        }
                        else if (BillingType.ToUpper() == "Quarterly")
                        {
                            nextdue = paydate.AddMonths(4);
                        }
                        else if (BillingType.ToUpper() == "Half-Yearly")
                        {
                            nextdue = paydate.AddMonths(6);
                        }
                        else if (BillingType.ToUpper() == "Annually")
                        {
                            nextdue = paydate.AddMonths(12);
                        }
                        if (nextdue == currentdate)
                        {
                            sb.Append(dt.Rows[i]["agentname"].ToString() + "~" + dt.Rows[i]["BillingEmail"].ToString() + "~" + nextdue + "~pay^");
                        }
                        string[] strC = sb.ToString().Split('^');
                        if (strC.Length > 1)
                        {
                            for (int j = 0; j < strC.Length - 1; j++)
                            {
                                string[] strT = strC[j].Split('~');
                                string agent = strT[0]; string email = strT[1]; string nextduedate = strT[2]; string mode = strT[3];

                                AuthorizeDotNetModel parentModel = new AuthorizeDotNetModel();
                                CreditCardDetailsModel creditCardDetails = new CreditCardDetailsModel();
                                creditCardDetails.CardNumber = Decrypt(dt.Rows[i]["CardNumber"].ToString());
                                creditCardDetails.ExpDate = Decrypt(dt.Rows[i]["ExpiryDate"].ToString());  //"1028";
                                creditCardDetails.CardCode = Decrypt(dt.Rows[i]["CVV"].ToString());
                                parentModel.creditCardDetails = creditCardDetails;

                                CustomerBillingInfoModel customerBillingInfo = new CustomerBillingInfoModel();
                                customerBillingInfo.FirstName = agent;
                                customerBillingInfo.LastName = "";
                                customerBillingInfo.Address = dt.Rows[i]["BillingAdd1"].ToString();
                                customerBillingInfo.City = dt.Rows[i]["BillingCity"].ToString();
                                customerBillingInfo.ZipCode = dt.Rows[i]["BillingZip"].ToString();
                                customerBillingInfo.Country = "USA";
                                customerBillingInfo.State = dt.Rows[i]["BillingState"].ToString();
                                customerBillingInfo.CompanyName = dt.Rows[i]["BusinessName"].ToString();
                                customerBillingInfo.EmailAddress = email;
                                customerBillingInfo.PhoneNumber = dt.Rows[i]["BillingPhone"].ToString();
                                customerBillingInfo.Fax = "";
                                parentModel.customerBillingInfo = customerBillingInfo;

                                List<LineItemsModel> lineItems = new List<LineItemsModel>();
                                LineItemsModel customerLineItems = new LineItemsModel();
                                customerLineItems.Item = "1";
                                customerLineItems.ItemName = "CreditReversalGuru";
                                customerLineItems.Description = "CreditReversalGuru";
                                customerLineItems.Quantity = Convert.ToInt32(1);
                                customerLineItems.Unitprice = Convert.ToDouble(dt.Rows[i]["SetupFee"].ToString());
                                lineItems.Add(customerLineItems);
                                parentModel.customerLineItems = lineItems;

                                CustomerOrderInformationModel customerOrderInfo = new CustomerOrderInformationModel();
                                customerOrderInfo.InVoice = "";
                                customerOrderInfo.Description = "";
                                parentModel.customerOrderInfo = customerOrderInfo;

                                CustomerShippingInformationModel customerShippingInfo = new CustomerShippingInformationModel();
                                customerShippingInfo.FirstName = agent;
                                customerShippingInfo.LastName = "";
                                customerShippingInfo.Address = dt.Rows[i]["BillingAdd1"].ToString();
                                customerShippingInfo.City = dt.Rows[i]["BillingCity"].ToString();
                                customerShippingInfo.ZipCode = dt.Rows[i]["BillingZip"].ToString();
                                customerShippingInfo.Country = "USA";
                                customerShippingInfo.State = dt.Rows[i]["BillingState"].ToString();
                                customerShippingInfo.CompanyName = dt.Rows[i]["BusinessName"].ToString();
                                parentModel.customerShippingInfo = customerShippingInfo;

                                var response = (dynamic)null;
                                response = AuthPayment.AuthorizeandCaptureTransaction(new Decimal(dt.Rows[i]["SetupFee"].ToString().StringToDouble(0)), parentModel, "");
                                AgentBillingTransactions agentBillingTransactions = new AgentBillingTransactions();
                                agentBillingTransactions.AgentId = dt.Rows[i]["AgentId"].ToString().StringToInt(0);

                                if (response != null)
                                {
                                    if (response.Status == "SUCCESS")
                                    {
                                        agentBillingTransactions.TransactionId = response.TransactionId;
                                        agentBillingTransactions.ResponseCode = response.ResponseCode;
                                        agentBillingTransactions.MessageCode = response.MessageCode;
                                        agentBillingTransactions.Description = response.Description;
                                        agentBillingTransactions.AuthorizeCode = response.AuthorizeCode;
                                        agentBillingTransactions.Status = response.Status;
                                        agentBillingTransactions.isNextAttempt = 0;
                                    }
                                    else
                                    {
                                        agentBillingTransactions.isNextAttempt = 1;
                                        string errormsg = "";
                                        string ErrorCode = response.ErrorCode != null ? response.ErrorCode : "";
                                        string ErrorText = response.ErrorMessage != null ? response.ErrorMessage : "";
                                        string msgInvalidCard = "Your card issuer due to " + "<b>\" Invalid credit card number. \"</b>",
                                         msgInvalidCVV = "Your card issuer due to " + "<b>\" Invalid CVV number. \"</b>",
                                         msgCardExpired = "Your card issuer due to " + "<b>\" Expiration of your credit card. \"</b>",
                                         msgInvalidExpirationDate = "Your card issuer due to " + "<b>\" Invalid credit card expiration date. \"</b>",
                                         msgPaymentGateway = " Payment gateway issues";
                                        //Payment failure mail send to customer
                                        if (ErrorCode == "8") //The credit card has expired
                                        {
                                            errormsg = msgCardExpired;
                                        }
                                        else if (ErrorCode == "6" || ErrorCode == "37" || ErrorText.ToUpper().Contains("CARDNUMBER")) //The credit card number is invalid.
                                        {
                                            errormsg = msgInvalidCard;
                                        }
                                        else if (ErrorCode == "7" || ErrorText.ToUpper().Contains("EXPIRATIONDATE")) //The credit card expiration date is invalid.
                                        {
                                            errormsg = msgInvalidExpirationDate;
                                        }
                                        else if (ErrorCode == "11") //A duplicate transaction has been submitted.
                                        {
                                            errormsg = msgPaymentGateway;
                                        }
                                        else if (ErrorCode == "13") //The merchant API Login ID is invalid or the account is inactive.
                                        {
                                            errormsg = msgPaymentGateway;
                                        }
                                        else if (ErrorCode == "16") //The transaction was not found.
                                        {
                                            errormsg = msgPaymentGateway;
                                        }
                                        else if (ErrorCode == "17" || ErrorCode == "28") //The merchant does not accept this type of credit card.
                                        {
                                            errormsg = msgInvalidCard;
                                        }
                                        else if (ErrorCode == "19" || ErrorCode == "23" || ErrorCode == "25" || ErrorCode == "26") //An error occurred during processing. Please try again in 5 minutes..
                                        {
                                            errormsg = msgPaymentGateway;
                                        }
                                        else if (ErrorCode == "35") //An error occurred during processing.Call Merchant Service Provider.
                                        {
                                            errormsg = msgPaymentGateway;
                                        }
                                        else if (ErrorCode == "44" || ErrorCode == "65" || ErrorCode == "78" || ErrorText.ToUpper().Contains("CARDCODE")) //Invalid CVV.
                                        {
                                            errormsg = msgInvalidCVV;
                                        }
                                        string errMsg = "Payment was declined. " + errormsg;
                                        errMsg = errMsg.Replace("<b>", " "); errMsg = errMsg.Replace("</b>", " ");
                                        agentBillingTransactions.ErrorCode = response.ErrorCode;
                                        agentBillingTransactions.ErrorMessage = response.ErrorMessage;
                                        agentBillingTransactions.Status = response.Status;
                                    }
                                    sql = "INSERT INTO Billing(AgentId,TransactionNo,CardType,PaymentMethodId,PaymentType,PaymentStatus, "
                                           + " PaymentDate,isNextAttempt) VALUES(" + dt.Rows[i]["AgentId"].ToString() + ",'" + agentBillingTransactions.TransactionId
                                           + "','" + dt.Rows[i]["CardType"].ToString() + "'," + dt.Rows[i]["PaymentMethodId"].ToString()
                                           + ",'CREDIT CARD','" + agentBillingTransactions.Status + "',getdate()," + agentBillingTransactions.isNextAttempt + " );";
                                    utilities.ExecuteString(sql, true);
                                    AddAgentBillingTransactions(agentBillingTransactions);
                                    if (response.Status == "SUCCESS")
                                    {
                                        sendmail(email, "Payment Success.", agent, mailtemplate("paymentsuccess", agent, nextduedate), "Payment Success");
                                    }
                                    else
                                    {
                                        sendmail(email, "Payment Failed.", agent, mailtemplate("paymentfail", agent, nextduedate), "Payment Fail");
                                    }
                                }
                                //send mails
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            { SetMessage("AgentPayments" + ex.Message); }
            return res;
        }
        public int AgentPaymentsNextAttempt()
        {
            int res = 0;
            try
            {
                string sql = " SELECT  a.PaymentStatus,a.PaymentMethodId,c.BillingPhone, c.BusinessName, c.BillingZip, c.BillingState, c.BillingCity, "
                    + " c.BillingAdd1,c.BillingAdd2, p.SetupFee,b.CardNumber,b.CardType,b.CVV,b.ExpiryDate , "
                  + " c.FirstName+' '+c.LastName agentname,c.BillingEmail, a.AgentId, "
                  + " CONVERT(VARCHAR(10), max(a.PaymentDate), 101) paydate,b.BillingType FROM Billing a, AgentBilling b,Agent c , Pricing p "
                  + " where a.PaymentMethodId = b.AgentBillingId and c.AgentId = b.AgentId and p.PricingId=c.PricingPlan  "
                    + "  and PaymentDate in (select max(PaymentDate) from Billing where AgentId=a.AgentId) "
                    + " and isnull(isNextAttempt,0)=1 and  isnull(isNextAttemptMail,0)=1 and c.Status=1 "
                  + " group by   a.PaymentStatus,a.PaymentMethodId,c.BillingEmail, a.AgentId,b.BillingType,FirstName,LastName, "
                  + " b.CardNumber,b.CardType,b.CVV,b.ExpiryDate , p.SetupFee,c.BillingZip, c.BillingState, c.BillingCity, c.BillingAdd1,"
                  + " c.BillingAdd2,c.BillingPhone, c.BusinessName ";
                DBUtilities utilities = new DBUtilities();
                DataTable dt = utilities.GetDataTable(sql);
                StringBuilder sb = new StringBuilder();
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    string paymentstatus = dt.Rows[i]["PaymentStatus"].ToString();
                    if (paymentstatus.ToUpper() == "FAILURE")
                    {
                        DateTime currentdate = DateTime.Now.Date;
                        DateTime nextdue = DateTime.Now.Date;
                        DateTime paydate = dt.Rows[i]["paydate"].ToString().stringToCultureInfoDateTime();
                        string BillingType = dt.Rows[i]["BillingType"].ToString();
                        if (BillingType.ToUpper() == "MONTHLY")
                        {
                            nextdue = paydate.AddMonths(1);
                        }
                        else if (BillingType.ToUpper() == "Quarterly")
                        {
                            nextdue = paydate.AddMonths(4);
                        }
                        else if (BillingType.ToUpper() == "Half-Yearly")
                        {
                            nextdue = paydate.AddMonths(6);
                        }
                        else if (BillingType.ToUpper() == "Annually")
                        {
                            nextdue = paydate.AddMonths(12);
                        }
                        if (nextdue.AddDays(7) == currentdate)
                        {
                            sb.Append(dt.Rows[i]["agentname"].ToString() + "~" + dt.Rows[i]["BillingEmail"].ToString() + "~" + nextdue + "~pay^");
                        }
                        string[] strC = sb.ToString().Split('^');
                        if (strC.Length > 1)
                        {
                            for (int j = 0; j < strC.Length - 1; j++)
                            {
                                string[] strT = strC[j].Split('~');
                                string agent = strT[0]; string email = strT[1]; string nextduedate = strT[2]; string mode = strT[3];

                                AuthorizeDotNetModel parentModel = new AuthorizeDotNetModel();
                                CreditCardDetailsModel creditCardDetails = new CreditCardDetailsModel();
                                creditCardDetails.CardNumber = Decrypt(dt.Rows[i]["CardNumber"].ToString());
                                creditCardDetails.ExpDate = Decrypt(dt.Rows[i]["ExpiryDate"].ToString());  //"1028";
                                creditCardDetails.CardCode = Decrypt(dt.Rows[i]["CVV"].ToString());
                                parentModel.creditCardDetails = creditCardDetails;

                                CustomerBillingInfoModel customerBillingInfo = new CustomerBillingInfoModel();
                                customerBillingInfo.FirstName = agent;
                                customerBillingInfo.LastName = "";
                                customerBillingInfo.Address = dt.Rows[i]["BillingAdd1"].ToString();
                                customerBillingInfo.City = dt.Rows[i]["BillingCity"].ToString();
                                customerBillingInfo.ZipCode = dt.Rows[i]["BillingZip"].ToString();
                                customerBillingInfo.Country = "USA";
                                customerBillingInfo.State = dt.Rows[i]["BillingState"].ToString();
                                customerBillingInfo.CompanyName = dt.Rows[i]["BusinessName"].ToString();
                                customerBillingInfo.EmailAddress = email;
                                customerBillingInfo.PhoneNumber = dt.Rows[i]["BillingPhone"].ToString();
                                customerBillingInfo.Fax = "";
                                parentModel.customerBillingInfo = customerBillingInfo;

                                List<LineItemsModel> lineItems = new List<LineItemsModel>();
                                LineItemsModel customerLineItems = new LineItemsModel();
                                customerLineItems.Item = "1";
                                customerLineItems.ItemName = "CreditReversalGuru";
                                customerLineItems.Description = "CreditReversalGuru";
                                customerLineItems.Quantity = Convert.ToInt32(1);
                                customerLineItems.Unitprice = Convert.ToDouble(dt.Rows[i]["SetupFee"].ToString());
                                lineItems.Add(customerLineItems);
                                parentModel.customerLineItems = lineItems;

                                CustomerOrderInformationModel customerOrderInfo = new CustomerOrderInformationModel();
                                customerOrderInfo.InVoice = "";
                                customerOrderInfo.Description = "";
                                parentModel.customerOrderInfo = customerOrderInfo;

                                CustomerShippingInformationModel customerShippingInfo = new CustomerShippingInformationModel();
                                customerShippingInfo.FirstName = agent;
                                customerShippingInfo.LastName = "";
                                customerShippingInfo.Address = dt.Rows[i]["BillingAdd1"].ToString();
                                customerShippingInfo.City = dt.Rows[i]["BillingCity"].ToString();
                                customerShippingInfo.ZipCode = dt.Rows[i]["BillingZip"].ToString();
                                customerShippingInfo.Country = "USA";
                                customerShippingInfo.State = dt.Rows[i]["BillingState"].ToString();
                                customerShippingInfo.CompanyName = dt.Rows[i]["BusinessName"].ToString();
                                parentModel.customerShippingInfo = customerShippingInfo;

                                var response = (dynamic)null;
                                response = AuthPayment.AuthorizeandCaptureTransaction(new Decimal(dt.Rows[i]["SetupFee"].ToString().StringToDouble(0)), parentModel, "");
                                AgentBillingTransactions agentBillingTransactions = new AgentBillingTransactions();
                                agentBillingTransactions.AgentId = dt.Rows[i]["AgentId"].ToString().StringToInt(0);
                                if (response != null)
                                {
                                    if (response.Status == "SUCCESS")
                                    {
                                        agentBillingTransactions.TransactionId = response.TransactionId;
                                        agentBillingTransactions.ResponseCode = response.ResponseCode;
                                        agentBillingTransactions.MessageCode = response.MessageCode;
                                        agentBillingTransactions.Description = response.Description;
                                        agentBillingTransactions.AuthorizeCode = response.AuthorizeCode;
                                        agentBillingTransactions.Status = response.Status;
                                        agentBillingTransactions.isNextAttempt = 0;
                                    }
                                    else
                                    {
                                        agentBillingTransactions.isNextAttempt = 1;
                                        string errormsg = "";
                                        string ErrorCode = response.ErrorCode != null ? response.ErrorCode : "";
                                        string ErrorText = response.ErrorMessage != null ? response.ErrorMessage : "";
                                        string msgInvalidCard = "Your card issuer due to " + "<b>\" Invalid credit card number. \"</b>",
                                         msgInvalidCVV = "Your card issuer due to " + "<b>\" Invalid CVV number. \"</b>",
                                         msgCardExpired = "Your card issuer due to " + "<b>\" Expiration of your credit card. \"</b>",
                                         msgInvalidExpirationDate = "Your card issuer due to " + "<b>\" Invalid credit card expiration date. \"</b>",
                                         msgPaymentGateway = " Payment gateway issues";
                                        //Payment failure mail send to customer
                                        if (ErrorCode == "8") //The credit card has expired
                                        {
                                            errormsg = msgCardExpired;
                                        }
                                        else if (ErrorCode == "6" || ErrorCode == "37" || ErrorText.ToUpper().Contains("CARDNUMBER")) //The credit card number is invalid.
                                        {
                                            errormsg = msgInvalidCard;
                                        }
                                        else if (ErrorCode == "7" || ErrorText.ToUpper().Contains("EXPIRATIONDATE")) //The credit card expiration date is invalid.
                                        {
                                            errormsg = msgInvalidExpirationDate;
                                        }
                                        else if (ErrorCode == "11") //A duplicate transaction has been submitted.
                                        {
                                            errormsg = msgPaymentGateway;
                                        }
                                        else if (ErrorCode == "13") //The merchant API Login ID is invalid or the account is inactive.
                                        {
                                            errormsg = msgPaymentGateway;
                                        }
                                        else if (ErrorCode == "16") //The transaction was not found.
                                        {
                                            errormsg = msgPaymentGateway;
                                        }
                                        else if (ErrorCode == "17" || ErrorCode == "28") //The merchant does not accept this type of credit card.
                                        {
                                            errormsg = msgInvalidCard;
                                        }
                                        else if (ErrorCode == "19" || ErrorCode == "23" || ErrorCode == "25" || ErrorCode == "26") //An error occurred during processing. Please try again in 5 minutes..
                                        {
                                            errormsg = msgPaymentGateway;
                                        }
                                        else if (ErrorCode == "35") //An error occurred during processing.Call Merchant Service Provider.
                                        {
                                            errormsg = msgPaymentGateway;
                                        }
                                        else if (ErrorCode == "44" || ErrorCode == "65" || ErrorCode == "78" || ErrorText.ToUpper().Contains("CARDCODE")) //Invalid CVV.
                                        {
                                            errormsg = msgInvalidCVV;
                                        }
                                        string errMsg = "Payment was declined. " + errormsg;
                                        errMsg = errMsg.Replace("<b>", " "); errMsg = errMsg.Replace("</b>", " ");
                                        agentBillingTransactions.ErrorCode = response.ErrorCode;
                                        agentBillingTransactions.ErrorMessage = response.ErrorMessage;
                                        agentBillingTransactions.Status = response.Status;
                                    }

                                    AddAgentBillingTransactions(agentBillingTransactions);
                                    if (response.Status == "SUCCESS")
                                    {
                                        sql = "INSERT Billing(AgentId,TransactionNo,CardType,PaymentMethodId,PaymentType,PaymentStatus, "
                                          + " PaymentDate) VALUES(" + dt.Rows[i]["AgentId"].ToString() + ",'" + agentBillingTransactions.TransactionId
                                          + "','" + dt.Rows[i]["CardType"].ToString() + "'," + dt.Rows[i]["PaymentMethodId"].ToString()
                                          + ",'CREDIT CARD','" + agentBillingTransactions.Status + "','" + nextdue.ToShortDateString().stringToCultureInfoDateTime() + "');";
                                        utilities.ExecuteString(sql, true);
                                        sql = "UPDATE Billing SET isNextAttempt=0 WHERE AgentId=" + dt.Rows[i]["AgentId"].ToString()
                                           + " and CONVERT(VARCHAR(10), PaymentDate, 101)='" + dt.Rows[i]["paydate"].ToString() + "'";
                                        utilities.ExecuteString(sql, true);
                                        sendmail(email, "Payment Success.", agent, mailtemplate("paymentsuccess", agent, nextdue.ToShortDateString()), "Payment Next Attempt Success");
                                    }
                                    else
                                    {
                                        sql = "UPDATE Billing SET PaymentStatus='SECOND ATTEMPT FAILURE', isNextAttempt=0 WHERE AgentId=" + dt.Rows[i]["AgentId"].ToString()
                                            + " and CONVERT(VARCHAR(10), PaymentDate, 101)='" + dt.Rows[i]["paydate"].ToString() + "'";
                                        utilities.ExecuteString(sql, true);
                                        sql = "UPDATE Users SET Status=0 WHERE UserRole='agentadmin' and AgentClientId=" + dt.Rows[i]["AgentId"].ToString();
                                        utilities.ExecuteString(sql, true);
                                        sql = "UPDATE Agent SET Status=0 WHERE AgentId=" + dt.Rows[i]["AgentId"].ToString();
                                        utilities.ExecuteString(sql, true);
                                        sendmail(email, "Payment Failed.", agent, mailtemplate("secondpaymentfail", agent, nextduedate), "Payment Next Attempt Fail");
                                    }
                                }
                                //send mails
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            { SetMessage("AgentPaymentsNextAttempt" + ex.Message); }
            return res;
        }
        public bool AddAgentBillingTransactions(AgentBillingTransactions agent)
        {
            bool status = false;
            long res = 0;
            try
            {
                string sql = "Insert Into AgentBillingTransactions(AgentId,TransactionId,ResponseCode,MessageCode,Description, "
                    + " AuthorizeCode,ErrorCode,ErrorMessage,Status,IPAddress) values "
                    + " (@AgentId,@TransactionId,@ResponseCode,@MessageCode,@Description,@AuthorizeCode,@ErrorCode, "
                    + " @ErrorMessage,@Status,@IPAddress)";
                SqlCommand cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@AgentId", agent.AgentId);
                cmd.Parameters.AddWithValue("@TransactionId", string.IsNullOrEmpty(agent.TransactionId) ? "" : agent.TransactionId);
                cmd.Parameters.AddWithValue("@ResponseCode", string.IsNullOrEmpty(agent.ResponseCode) ? "" : agent.ResponseCode);
                cmd.Parameters.AddWithValue("@MessageCode", string.IsNullOrEmpty(agent.MessageCode) ? "" : agent.MessageCode);
                cmd.Parameters.AddWithValue("@Description", string.IsNullOrEmpty(agent.Description) ? "" : agent.Description);
                cmd.Parameters.AddWithValue("@AuthorizeCode", string.IsNullOrEmpty(agent.AuthorizeCode) ? "" : agent.AuthorizeCode);
                cmd.Parameters.AddWithValue("@ErrorCode", string.IsNullOrEmpty(agent.ErrorCode) ? "" : agent.ErrorCode);

                cmd.Parameters.AddWithValue("@ErrorMessage", string.IsNullOrEmpty(agent.ErrorMessage) ? "" : agent.ErrorMessage);
                cmd.Parameters.AddWithValue("@Status", string.IsNullOrEmpty(agent.Status) ? "" : agent.Status);
                cmd.Parameters.AddWithValue("@IPAddress", string.IsNullOrEmpty(agent.IPAddress) ? "" : agent.IPAddress);
                cmd.CommandText = sql;
                DBUtilities dBUtilities = new DBUtilities();
                res = dBUtilities.ExecuteInsertCommand(cmd, true);
                if (res == 1)
                {
                    status = true;
                }
            }
            catch (Exception ex) { SetMessage("AddAgentBillingTransactions" + ex.Message); }
            return status;
        }
        private void SetMessage(string content)
        {
            FileStream fs = new FileStream(AppDomain.CurrentDomain.BaseDirectory + "\\LogFile.txt", FileMode.OpenOrCreate); //Use Append for
            StreamWriter sw = new StreamWriter(fs);
            sw.BaseStream.Seek(0, SeekOrigin.End);
            sw.WriteLine(content);
            sw.Flush();
            sw.Close();
        }
        public string Encrypt(string clearText)
        {
            try
            {
                string EncryptionKey = "M3";
                byte[] clearBytes = Encoding.Unicode.GetBytes(clearText);
                using (Aes encryptor = Aes.Create())
                {
                    Rfc2898DeriveBytes pdb = new Rfc2898DeriveBytes(EncryptionKey, new byte[] { 0x49, 0x76, 0x61, 0x6e, 0x20, 0x4d, 0x65, 0x64, 0x76, 0x65, 0x64, 0x65, 0x76 });
                    encryptor.Key = pdb.GetBytes(32);
                    encryptor.IV = pdb.GetBytes(16);
                    using (MemoryStream ms = new MemoryStream())
                    {
                        using (CryptoStream cs = new CryptoStream(ms, encryptor.CreateEncryptor(), CryptoStreamMode.Write))
                        {
                            cs.Write(clearBytes, 0, clearBytes.Length);
                            cs.Close();
                        }
                        clearText = Convert.ToBase64String(ms.ToArray());
                    }
                }
            }
            catch (Exception ex)
            {
                SetMessage("Encrypt: " + ex.Message);
            }
            return clearText;
        }
        public string Decrypt(string cipherText)
        {
            try
            {
                string EncryptionKey = "M3";
                cipherText = cipherText.Replace(" ", "+");
                byte[] cipherBytes = Convert.FromBase64String(cipherText);
                using (Aes encryptor = Aes.Create())
                {
                    Rfc2898DeriveBytes pdb = new Rfc2898DeriveBytes(EncryptionKey, new byte[] { 0x49, 0x76, 0x61, 0x6e, 0x20, 0x4d, 0x65, 0x64, 0x76, 0x65, 0x64, 0x65, 0x76 });
                    encryptor.Key = pdb.GetBytes(32);
                    encryptor.IV = pdb.GetBytes(16);
                    using (MemoryStream ms = new MemoryStream())
                    {
                        using (CryptoStream cs = new CryptoStream(ms, encryptor.CreateDecryptor(), CryptoStreamMode.Write))
                        {
                            cs.Write(cipherBytes, 0, cipherBytes.Length);
                            cs.Close();
                        }
                        cipherText = Encoding.Unicode.GetString(ms.ToArray());
                    }
                }
            }
            catch (Exception ex)
            {
                SetMessage("Decrypt: " + ex.Message);
            }
            return cipherText;
        }
        public string mailtemplate(string type, string name, string date)
        {
            StringBuilder sb = new StringBuilder();
            try
            {
               
                if (type == "14" || type == "7")
                {
                    sb.Append("<br /> Dear " + name + ", <br /> <br />");
                    sb.Append("&nbsp; &nbsp; This is the  reminder of your payment.<br />");
                    sb.Append("&nbsp; &nbsp; Please pay the bill by " + date + " <br />");
                }
                else if (type == "nxtAttempt")
                {
                    sb.Append("<br /> Dear " + name + ", <br /> <br />");
                    sb.Append("&nbsp; &nbsp; This is the  reminder of your payment.<br />");
                    sb.Append("&nbsp; &nbsp; Please pay the bill by " + date + " <br />");
                }
                else if (type == "paymentsuccess")
                {
                    sb.Append("<br /> Dear " + name + ", <br /> <br />");
                    sb.Append("&nbsp; &nbsp; We have recieved Your payment via credit card.<br />");
                    //sb.Append("&nbsp; &nbsp; Please pay the bill by " + date + " <br />");
                }
                else if (type == "paymentfail")
                {
                    sb.Append("<br /> Dear " + name + ", <br /> <br />");
                    sb.Append("&nbsp; &nbsp; Your payment failed. Kindly make your payment with immediate effect by next 7 days. <br />");
                    sb.Append("&nbsp; &nbsp; Other wise your account will be blocked. <br />");
                    //sb.Append("&nbsp; &nbsp; Please pay the bill by " + date + " <br />");
                }
                else if (type == "secondpaymentfail")
                {
                    sb.Append("<br /> Dear " + name + ", <br /> <br />");
                    sb.Append("&nbsp; &nbsp; Your account blocked  due to payment failed. <br />");
                    sb.Append("&nbsp; &nbsp; Please contact support team. <br />");
                    //sb.Append("&nbsp; &nbsp; Please pay the bill by " + date + " <br />");
                }

                sb.Append("<br /><br /> Thanks, <br /> Support Team.");
            }
            catch (Exception ex)
            {
                SetMessage("mailtemplate: " + ex.Message);
            }
            return sb.ToString();
        }
        protected override void OnStop()
        {
            _timer1.Enabled = false;
            SetMessage("stop service " + DateTime.Now);
        }
    }
    public class AgentBillingTransactions
    {
        public int isNextAttempt { get; set; }
        public int AgentId { get; set; }
        public string TransactionId { get; set; }
        public string ResponseCode { get; set; }
        public string MessageCode { get; set; }
        public string Description { get; set; }
        public string AuthorizeCode { get; set; }
        public string ErrorCode { get; set; }
        public string ErrorMessage { get; set; }
        public string Status { get; set; }
        public string IPAddress { get; set; }
    }
    public class AgentBilling
    {
        public int AgentBillingId { get; set; }
        public int AgentId { get; set; }
        public int PricingPlan { get; set; }
        public string BillingType { get; set; }
        public string CardType { get; set; }
        public string CardNumber { get; set; }
        public string ExpiryDate { get; set; }
        public string CVV { get; set; }
        public string BillingZipCode { get; set; }
        public string Status { get; set; }
        public int CreatedBy { get; set; }
        public string CreatedDate { get; set; }
        public int IsPrimary { get; set; }
    }
}
