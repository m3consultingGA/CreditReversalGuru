﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.IO;
using System.Xml;

namespace CreditReversalService
{
    public class DBUtilities
    {
        public readonly string connectionString = "";
        private SqlConnection sqlCon = new SqlConnection();
        public string errorMessage = @"";
        public string ConnectionString => connectionString;
        private void SetMessage(string content)
        {
            FileStream fs = new FileStream(AppDomain.CurrentDomain.BaseDirectory + "\\LogFile.txt", FileMode.OpenOrCreate); //Use Append for
            StreamWriter sw = new StreamWriter(fs);
            sw.BaseStream.Seek(0, SeekOrigin.End);
            sw.WriteLine(content);
            sw.Flush();
            sw.Close();
        }
        public bool OpenDB()
        {
            bool res = false;
            try
            {
                XmlDataDocument xmldoc = new XmlDataDocument();
                XmlNodeList xmlnode;
                int i = 0;
                string str = null;
                FileStream fs = new FileStream(AppDomain.CurrentDomain.BaseDirectory + "\\CreditReversal.xml", FileMode.Open, FileAccess.Read);
                xmldoc.Load(fs);
                string connection = xmldoc.GetElementsByTagName("Connection")[0].ChildNodes.Item(0).InnerText.Trim();
                sqlCon.ConnectionString = connection;
                sqlCon.Open();
            }
            catch (Exception ex)
            {
                errorMessage += ex.Message + System.Environment.NewLine;
                res = false; ;
                SetMessage("OpenDB:" + ex.Message);
            }
            return res;
        }

        public void CloseDB()
        {
            try { sqlCon.Close(); }
            catch (Exception ex) { SetMessage("CloseDB:" + ex.Message); }
        }

        public DataSet GetDataSet(string sql)
        {
            return GetDataSet(sql, true);
        }
        public DataSet GetDataSet(string sql, bool closeFlag)
        {
            DataSet res = new DataSet();
            try
            {
                if (sqlCon.State != ConnectionState.Open)
                    OpenDB();
                SqlDataAdapter da = new SqlDataAdapter(sql, sqlCon);
                da.Fill(res);
            }
            catch (Exception ex) { }
            finally
            {
                if (closeFlag)
                    CloseDB();
            }
            return res;
        }


        public DataTable GetDataTable(string sql)
        {
            return GetDataTable(sql, true);
        }
        public DataTable GetDataTable(string sql, bool closeFlag)
        {
            DataTable res = new DataTable();
            try
            {
                if (sqlCon.State != ConnectionState.Open)
                    OpenDB();
                SqlDataAdapter da = new SqlDataAdapter(sql, sqlCon);
                da.Fill(res);
            }
            catch (Exception ex) { }
            finally
            {
                if (closeFlag)
                    CloseDB();
            }
            return res;
        }

        public long ExecuteString(string sql, bool closeFlag)
        {
            SqlCommand cmd = new SqlCommand(sql);
            return ExecuteInsertCommand(cmd, closeFlag);
        }

        public DataTable ExecuteCommand(SqlCommand cmd, bool closeFlag)
        {
            DataTable dt = new DataTable();
            try
            {
                if (sqlCon.State != ConnectionState.Open)
                {
                    OpenDB();
                }
                cmd.Connection = sqlCon;
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(dt);
            }
            catch (Exception ex) { }
            finally
            {
                if (closeFlag)
                {
                    sqlCon.Close();
                }
            }
            return dt;
        }

        public long ExecuteInsertCommand(SqlCommand cmd, bool closeFlag)
        {
            long res = 0;
            try
            {
                if (sqlCon.State != ConnectionState.Open)
                {
                    OpenDB();
                }
                cmd.Connection = sqlCon;
                res = cmd.ExecuteNonQuery();
            }
            catch (Exception ex) { }
            finally
            {
                if (closeFlag)
                {
                    sqlCon.Close();
                }
            }

            return res;
        }
        public long ExecuteCommand(string sql, bool closeFlag)
        {
            long res = 0;

            try
            {
                if (sqlCon.State != ConnectionState.Open)
                    OpenDB();
                SqlCommand cmd = new SqlCommand(sql, sqlCon);
                res = cmd.ExecuteNonQuery();
            }
            catch (Exception ex) { }
            finally
            {
                if (closeFlag)
                    CloseDB();
            }
            return res;

        }

        public object ExecuteScalar(string sql, bool closeFlag)
        {
            object res = 0;

            try
            {
                if (sqlCon.State != ConnectionState.Open)
                    OpenDB();
                SqlCommand cmd = new SqlCommand(sql, sqlCon);
                res = cmd.ExecuteScalar();
            }
            catch (Exception ex) { }
            finally
            {
                if (closeFlag)
                    CloseDB();
            }
            return res;

        }


        //public bool CheckUser(string user, string password)
        //{
        //    bool res = false;

        //    string sql = "SELECT DealerID from KCM_Telematic_Users where DealerID='" + user + "' AND DealerPassword='" + password + "' AND IsActive='Y'";
        //    DataTable dt = GetDataTable(sql, false);
        //    res = dt.Rows.Count == 1;
        //    sql = "Insert into Login_Audit(LoginID) values('" + user + "')";

        //    long cnt = ExecuteCommand(sql, true);
        //    return res;
        //}
        public DataRow GetDataRow(string sql)
        {
            DataRow row = null;
            DataTable dataTable = new DataTable();
            sqlCon.ConnectionString = ConnectionString;
            try
            {

                SqlCommand cmd = new SqlCommand(sql, sqlCon);
                SqlDataAdapter dataAdapter = new SqlDataAdapter();
                dataAdapter.SelectCommand = cmd;
                dataAdapter.Fill(dataTable);
                if (dataTable.Rows.Count > 0)
                {
                    row = dataTable.Rows[0];
                }
            }
            catch (Exception ex) { }

            return row;
        }
        public object ExecuteScalarCommand(SqlCommand cmd, bool closeFlag)
        {
            object res = string.Empty;

            try
            {
                if (sqlCon.State != ConnectionState.Open)
                    OpenDB();
                cmd.Connection = sqlCon;
                res = cmd.ExecuteScalar();
            }
            catch (Exception ex) { }
            finally
            {
                if (closeFlag)
                    CloseDB();
            }
            return res;

        }
        public DataTable getSettings()
        {
            DataTable dt = new DataTable();
            try
            {
                string sql = " SELECT  ConfigId,DBConnection,SendGridAPIKey,Fromemail,AuthApiLoginId,ApiTransactionKey "
                + " , SecretKey, AuthEnvironment,[14DaysMailLine1] as days14line1,[14DaysMailLine2] as days14line2, "
                + " [7DaysMailLine1] as days7line1,[7DaysMailLine2] as days7line2 "
                + " ,PaymentSuccessLine1,PaymentSuccessLine2,PaymentFailureLine1,PaymentFailureLine2,NextAttemptMailLine1 "
                + " ,NextAttemptMailLine2,SecondPaymentFailureLine1,SecondPaymentFailureLine2 FROM ServiceSettings ";
                dt = GetDataTable(sql);
            }
            catch (Exception ex)
            {

                SetMessage(ex.Message);
            }
            return dt;
        }
    }
}