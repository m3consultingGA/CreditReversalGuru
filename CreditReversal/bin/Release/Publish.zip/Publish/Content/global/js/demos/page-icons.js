$(function () {
  
  // Disable click of demo icons
  $('.fontawesome-icon-list a').click (function (e) {
    e.preventDefault ()
  })

})