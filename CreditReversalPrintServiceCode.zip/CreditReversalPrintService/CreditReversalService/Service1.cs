﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;
using SendGrid;
using SendGrid.Helpers.Mail;
using System.Threading;
using System.Configuration;
using System.IO;
using CreditReversalService;
using System.Data.SqlClient;
using System.Security.Cryptography;
using System.Xml;
using System.Timers;
using Timer = System.Timers.Timer;
using RestSharp;
using System.IO.Compression;
using Newtonsoft.Json;

namespace CreditReversalService
{
    [RunInstaller(true)]
    public partial class Service1 : ServiceBase
    {
        DBUtilities utilities = new DBUtilities();
        Timer _timer1 = new Timer();
        static string MailXStreamURL = string.Empty;
        static string USERID = string.Empty;
        static string PASSWORD = string.Empty;
        static string startPath = string.Empty;
        static string zipPath = string.Empty;
        static string template = string.Empty;
        public Service1()
        {
            try
            {
                DataTable dt = utilities.getSettings();
                if (dt.Rows.Count > 0)
                {
                    MailXStreamURL = dt.Rows[0]["MailXStreamURL"].ToString();
                    USERID = dt.Rows[0]["MXUSERID"].ToString();
                    PASSWORD = dt.Rows[0]["MXPASSWORD"].ToString();
                    startPath = dt.Rows[0]["ChallengesPath"].ToString();
                    zipPath = dt.Rows[0]["ChallengesPathResult"].ToString();
                    template = dt.Rows[0]["MXTemplate"].ToString();
                }
            }
            catch (Exception EX)
            {
                SetMessage("Service1-Init:" + EX.Message);
            }
            InitializeComponent();
        }
        protected override void OnStart(string[] args)
        {   //Get status and print orders
            SetMessage("Start: " + DateTime.Now);
            _timer1.Elapsed += new ElapsedEventHandler(MailXStream);
            _timer1.Interval = (1000 * 60 * 1); //30 mins
            _timer1.Enabled = true;
        }

        public void MailXStream(object sender, ElapsedEventArgs args)
        {
            try
            {
                _timer1.Enabled = false;
                _timer1.Stop();
                ChallengeOrders();
                _timer1.Enabled = true;
                _timer1.Start();
            }
            catch (Exception ex)
            {
                SetMessage("PrintOrders: " + ex.ToString());
            }
        }
        protected async Task ChallengeOrders()
        {
            try
            {
                try { await GetOrderStatus(); }
                catch (Exception ex) { SetMessage(ex.Message); }
                try { await SubmitPrit(); }
                catch (Exception ex) { SetMessage(ex.Message); }
            }
            catch (Exception ex)
            { }
        }

        public async Task GetOrderStatus()
        {

            try
            {
                SetMessage(MailXStreamURL);
                string sql = " SELECT [RowId],[OrderId],[ResponseCode],[ChallengeFileName],[OrderStatus],[AgentId], "
                    + " [ClientId],[OrderDate],[Status]   FROM ChallengeOrders ";
                DataTable dt = utilities.GetDataTable(sql);
                StringBuilder sb = new StringBuilder();
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    string OrderId = dt.Rows[i]["OrderId"].ToString();
                    if (!string.IsNullOrEmpty(OrderId))
                    {
                        var client = new RestClient(MailXStreamURL);
                        var request1 = new RestRequest(Method.POST);
                        request1.AddParameter("userid", USERID);
                        request1.AddParameter("passwd", PASSWORD);
                        request1.AddParameter("method", "GetOrderStatus");
                        request1.AddParameter("order_id", OrderId);
                        IRestResponse response = client.Execute(request1);
                        var content = response.Content;
                        if (content != "")
                        {
                            dynamic res = JsonConvert.DeserializeObject<dynamic>(content.ToString());
                            string status = res.status;
                            sql = " UPDATE ChallengeOrders SET  OrderStatus='" + status + "' WHERE OrderId='" + OrderId + "'";
                            utilities.ExecuteString(sql, false);
                        }
                    }
                }
                utilities.CloseDB();
            }
            catch (Exception ex)
            {
                utilities.CloseDB();
                SetMessage("PrintOrders: " + ex.ToString());
            }
        }
        public async Task ZipPdfFiles()
        {
            try
            {

                ZipFile.CreateFromDirectory(startPath, zipPath, CompressionLevel.Fastest, true);
            }
            catch (Exception ex)
            {
                SetMessage("ZipPdfFiles: " + ex.ToString());
            }

        }
        public async Task DeleteChallenges()
        {
            try
            {
                Array.ForEach(Directory.GetFiles(startPath),
              delegate (string path) { File.Delete(path); });
            }
            catch (Exception ex)
            {
                SetMessage("DeleteChallenges: " + ex.ToString());
            }
        }
        public async Task DeleteZipfile()
        {
            try
            {
                File.Delete(zipPath);
            }
            catch (Exception ex)
            {
                SetMessage("DeleteZipfile: " + ex.ToString());
            }
        }
        public async Task SubmitPrit()
        {
            try
            {
                if (Directory.EnumerateFileSystemEntries(startPath, "*.pdf").ToList<string>().Count != 0)
                {
                    await ZipPdfFiles();
                    await DeleteChallenges();
                    string val = DateTime.Now.Month.ToString() + DateTime.Now.Day.ToString() + DateTime.Now.Year.ToString() +
                   DateTime.Now.Hour.ToString() + DateTime.Now.Minute.ToString() + DateTime.Now.Second.ToString();
                    var client = new RestClient(MailXStreamURL);
                    var request1 = new RestRequest(Method.POST);
                    request1.AddParameter("userid", USERID);
                    request1.AddParameter("passwd", PASSWORD);
                    request1.AddParameter("method", "SubmitOrder");
                    request1.AddParameter("name", "Challenge-" + val);
                    request1.AddParameter("template", template);
                    request1.AddFile("file", zipPath);
                    IRestResponse response1 = client.Execute(request1);
                    var content = response1.Content;
                    await DeleteZipfile();
                    if (content != "")
                    {
                        dynamic res = JsonConvert.DeserializeObject<dynamic>(content.ToString());
                        string status = res.status;
                        string sql = " Insert into ChallengeOrders(OrderId,ResponseCode,ChallengeFileName,OrderStatus,OrderName) "
                             + " values('" + res.order_id + "','" + res.response_code + "','" + res.job_name + "','WAIT','Challenge-" + val + "')";
                        utilities.ExecuteString(sql, false);
                    }
                }
            }
            catch (Exception ex)
            {
                SetMessage("SubmitPrit: " + ex.ToString());
            }
        }
        private void SetMessage(string content)
        {
            FileStream fs = new FileStream(AppDomain.CurrentDomain.BaseDirectory + "\\LogFile.txt", FileMode.OpenOrCreate); //Use Append for
            StreamWriter sw = new StreamWriter(fs);
            sw.BaseStream.Seek(0, SeekOrigin.End);
            sw.WriteLine(content);
            sw.Flush();
            sw.Close();
        }
        protected override void OnStop()
        {
            _timer1.Enabled = false;
            SetMessage("stop service " + DateTime.Now);
        }
    }
}
